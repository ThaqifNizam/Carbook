<?php
include "db.php"; // your DB connection

// Include Bootstrap CSS CDN for styling messages
echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet">';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $username = isset($_POST['username']) ? htmlspecialchars(trim($_POST['username'])) : null;
    $email = htmlspecialchars(trim($_POST['email']));
    $password = trim($_POST['password']);

    // Check required fields  
    if (!empty($email) && !empty($password)) {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // ✅ Check if email already exists
        $checkEmail = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $checkEmail->bind_param("s", $email);
        $checkEmail->execute();
        $checkEmail->store_result();

        if ($checkEmail->num_rows > 0) {
            echo '<div class="container mt-5">';
            echo '<div class="alert alert-danger text-center" role="alert" style="max-width: 600px; margin: auto;">';
            echo '<strong>Error:</strong> Email already registered!';
            echo '</div>';
            echo '<div class="text-center"><a href="register.html" class="btn btn-primary">Try Again</a></div>';
            echo '</div>';
            $checkEmail->close();
            exit();
        }
        $checkEmail->close();

        // ✅ Check if username exists (if provided)
        if (!empty($username)) {
            $checkUsername = $conn->prepare("SELECT id FROM users WHERE username = ?");
            $checkUsername->bind_param("s", $username);
            $checkUsername->execute();
            $checkUsername->store_result();

            if ($checkUsername->num_rows > 0) {
                echo '<div class="container mt-5">';
                echo '<div class="alert alert-danger text-center" role="alert" style="max-width: 600px; margin: auto;">';
                echo '<strong>Error:</strong> Username already exists!';
                echo '</div>';
                echo '<div class="text-center"><a href="register.html" class="btn btn-primary">Try Again</a></div>';
                echo '</div>';
                $checkUsername->close();
                exit();
            }
            $checkUsername->close();
        } else {
            $username = null; // Explicitly set to NULL for binding
        }

        // ✅ Insert the new user
        $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $username, $email, $hashed_password);

        if ($stmt->execute()) {
            echo '<div class="container mt-5">';
            echo '<div class="alert alert-success text-center" role="alert" style="max-width: 600px; margin: auto;">';
            echo 'Registration successful! Redirecting to login...';
            echo '</div>';
            echo '</div>';

            // Redirect after short delay
            echo "<script>
                    setTimeout(() => { window.location.href = 'login.html'; }, 2000);
                  </script>";
        } else {
            echo '<div class="container mt-5">';
            echo '<div class="alert alert-danger text-center" role="alert" style="max-width: 600px; margin: auto;">';
            echo '<strong>Error:</strong> ' . htmlspecialchars($stmt->error);
            echo '</div>';
            echo '</div>';
        }

        $stmt->close();
    } else {
        echo '<div class="container mt-5">';
        echo '<div class="alert alert-warning text-center" role="alert" style="max-width: 600px; margin: auto;">';
        echo 'Please fill in all required fields!';
        echo '</div>';
        echo '<div class="text-center"><a href="register.html" class="btn btn-primary">Try Again</a></div>';
        echo '</div>';
    }
}

$conn->close();
?>
