<?php
$servername = "localhost";
$username = "root";     // default XAMPP user
$password = "";         // default is blank
$dbname = "carbook";    // must match your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
