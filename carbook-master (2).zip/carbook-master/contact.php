<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

$message_to_show = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fallback for PHP 5.6 (no null coalescing operator)
    $name    = isset($_POST['name']) ? strip_tags(trim($_POST['name'])) : '';
    $email   = isset($_POST['email']) ? filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL) : '';
    $subject = isset($_POST['subject']) ? strip_tags(trim($_POST['subject'])) : '';
    $message = isset($_POST['message']) ? strip_tags(trim($_POST['message'])) : '';

    if (empty($name) || empty($subject) || empty($message) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message_to_show = "<p style='color:red;'>Please fill in all fields with valid information.</p>";
    } else {
        $mail = new PHPMailer(true);

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'thaqifjohari2009@gmail.com';
            $mail->Password   = 'vygy kfan odqd ypza';  // Gmail App Password
            $mail->SMTPSecure = 'tls'; // Use string here for PHP 5.6
            $mail->Port       = 587;

            // Recipients
            $mail->setFrom($email, $name);
            $mail->addAddress('thaqifjohari2009@gmail.com');

            // Content
            $mail->isHTML(false);
            $mail->Subject = $subject;
            $mail->Body    = "Name: $name\nEmail: $email\n\nMessage:\n$message";

            $mail->send();
            $message_to_show = "<p style='color:green;'>Thank you for contacting us! We will get back to you soon.</p>";
        } catch (Exception $e) {
            $message_to_show = "<p style='color:red;'>Message could not be sent. Mailer Error: {$mail->ErrorInfo}</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Contact Form Status</title>
</head>
<body>
    <?php
    if (!empty($message_to_show)) {
        echo $message_to_show;
    } else {
        echo "<p>Please submit the form.</p>";
    }
    ?>
</body>
</html>