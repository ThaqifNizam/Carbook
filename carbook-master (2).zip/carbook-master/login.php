<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    $sql = "SELECT id, password FROM users WHERE email = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $hashed_password);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                // Save user info in session
                $_SESSION['user_id'] = $id;
                $_SESSION['user_email'] = $email;

                // Redirect to homepage
                header('Location: http://localhost/carbook-master/index.html');
                exit();
            } else {
                echo "<script>alert('Wrong password!'); window.location.href='login.html';</script>";
                exit();
            }
        } else {
            echo "<script>alert('User not found!'); window.location.href='login.html';</script>";
            exit();
        }

        $stmt->close();
    } else {
        echo "<script>alert('Database error.'); window.location.href='login.html';</script>";
        exit();
    }
}

$conn->close();
?>
