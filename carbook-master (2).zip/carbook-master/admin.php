<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Carbook";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Only process POST requests
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get POST data and sanitize (real_escape_string protects against SQL injection)
    $selected_car = isset($_POST['selected_car']) ? $conn->real_escape_string(trim($_POST['selected_car'])) : '';
    $pickup_location = isset($_POST['pickup_location']) ? $conn->real_escape_string(trim($_POST['pickup_location'])) : '';
    $dropoff_location = isset($_POST['dropoff_location']) ? $conn->real_escape_string(trim($_POST['dropoff_location'])) : '';
    $pickup_date = isset($_POST['pickup_date']) ? trim($_POST['pickup_date']) : '';
    $dropoff_date = isset($_POST['dropoff_date']) ? trim($_POST['dropoff_date']) : '';
    $pickup_time = isset($_POST['pickup_time']) ? trim($_POST['pickup_time']) : '';

    // Validate required fields
    if (empty($pickup_location) || empty($dropoff_location) || empty($pickup_date) || empty($dropoff_date) || empty($pickup_time) || empty($selected_car)) {
        die("Please fill in all fields, including car selection.");
    }


    // Date formats
    $date_format_input = 'Y-m-d';  // From HTML input
    $date_format_db = 'Y-m-d';     // Same format for DB

    // Validate and convert pick-up date
    $pickup_date_obj = DateTime::createFromFormat($date_format_input, $pickup_date);
    $pickup_date_errors = DateTime::getLastErrors();
    if ($pickup_date_errors['warning_count'] > 0 || $pickup_date_errors['error_count'] > 0) {
        die("Invalid pick-up date format.");
    }
    $pickup_date_db = $pickup_date_obj->format($date_format_db);

    // Validate and convert drop-off date
    $dropoff_date_obj = DateTime::createFromFormat($date_format_input, $dropoff_date);
    $dropoff_date_errors = DateTime::getLastErrors();
    if ($dropoff_date_errors['warning_count'] > 0 || $dropoff_date_errors['error_count'] > 0) {
        die("Invalid drop-off date format.");
    }
    $dropoff_date_db = $dropoff_date_obj->format($date_format_db);

    // Validate time format (HH:MM 24-hour)
    if (!preg_match('/^(?:2[0-3]|[01][0-9]):[0-5][0-9]$/', $pickup_time)) {
        die("Invalid pick-up time format. Please use HH:MM (24-hour).");
    }

    // Prepare and execute insert statement
    $stmt = $conn->prepare("INSERT INTO bookings (pickup_location, dropoff_location, pickup_date, dropoff_date, pickup_time, selected_car) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $pickup_location, $dropoff_location, $pickup_date_db, $dropoff_date_db, $pickup_time, $selected_car);

    if ($stmt->execute()) {
        echo "<p style='color:green;'>Booking saved successfully!</p>";
    } else {
        echo "<p style='color:red;'>Error saving booking: " . htmlspecialchars($stmt->error) . "</p>";
    }

    $stmt->close();
}

// Show bookings table below (optional)
$sql = "SELECT pickup_location, dropoff_location, pickup_date, dropoff_date, pickup_time, selected_car FROM bookings";
$result = $conn->query($sql);

echo "<h2>Bookings</h2>";
echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr style='background-color: black; color: white;'>";
echo "<th>#</th><th>Pick-up location</th><th>Drop-off location</th><th>Pick-up date</th><th>Drop-off date</th><th>Pick-up time</th><th>Selected Car</th>";
echo "</tr>";

if ($result && $result->num_rows > 0) {
    $count = 1;
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td data-label='#'>" . $count++ . "</td>";
        echo "<td data-label='Pick-up Location'>" . htmlspecialchars($row['pickup_location']) . "</td>";
        echo "<td data-label='Drop-off Location'>" . htmlspecialchars($row['dropoff_location']) . "</td>";
        echo "<td data-label='Pick-up Date'>" . DateTime::createFromFormat('Y-m-d', $row['pickup_date'])->format('d/m/Y') . "</td>";
        echo "<td data-label='Drop-off Date'>" . DateTime::createFromFormat('Y-m-d', $row['dropoff_date'])->format('d/m/Y') . "</td>";
        echo "<td data-label='Pick-up Time'>" . htmlspecialchars($row['pickup_time']) . "</td>";
        echo "<td data-label='Selected Car'>" . htmlspecialchars($row['selected_car']) . "</td>";
        echo "</tr>";
    }

} else {
    echo "<tr><td colspan='6'>No bookings found</td></tr>";
}
echo "</table>";

$conn->close();
?>